<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'campus_events_hub_3';

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die('The website cannot connect to the database at the moment. Please try again later.');
}

mysqli_set_charset($conn, 'utf8mb4');
?>
