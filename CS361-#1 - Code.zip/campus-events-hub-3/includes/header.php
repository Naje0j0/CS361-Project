<?php
if (!isset($pageTitle)) {
    $pageTitle = 'Campus Events Hub';
}

$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SEU Student Activities Club events and student registration website">
    <title><?php echo htmlspecialchars($pageTitle); ?> | Campus Events Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-wrapper">
        <a class="brand" href="index.php" aria-label="Campus Events Hub home page">
            <span class="brand-mark">CE</span>
            <span>
                <strong>Campus Events Hub</strong>
                <small>SEU Student Activities Club</small>
            </span>
        </a>

        <nav class="main-nav" aria-label="Main navigation">
            <ul>
                <li><a class="<?php echo $currentPage === 'index.php' ? 'active' : ''; ?>" href="index.php">Home</a></li>
                <li><a class="<?php echo in_array($currentPage, ['events.php', 'event.php']) ? 'active' : ''; ?>" href="events.php">Events</a></li>
                <li><a class="<?php echo $currentPage === 'register.php' ? 'active' : ''; ?>" href="register.php">Register</a></li>
                <li><a class="<?php echo $currentPage === 'registrations.php' ? 'active' : ''; ?>" href="registrations.php">Registrations</a></li>
                <li><a class="<?php echo $currentPage === 'about.php' ? 'active' : ''; ?>" href="about.php">About & Contact</a></li>
            </ul>
        </nav>
    </div>
</header>
<main>
