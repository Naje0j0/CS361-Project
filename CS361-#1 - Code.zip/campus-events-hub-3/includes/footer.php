</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <h2>Campus Events Hub</h2>
            <p>A university project for managing student activities and event registrations.</p>
        </div>
        <div>
            <h2>Contact</h2>
            <p>Email: activities@seu.edu.sa</p>
            <p>Location: Saudi Electronic University, Riyadh</p>
        </div>
    </div>
    <p class="copyright">&copy; 2026 SEU Student Activities Club. Academic project.</p>
</footer>
</body>
</html>
