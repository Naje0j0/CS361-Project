<?php
require_once 'includes/db.php';
$pageTitle = 'Registrations';

$sql = "SELECT registrations.*, events.title AS event_title
        FROM registrations
        JOIN events ON registrations.event_id = events.id
        ORDER BY registrations.registration_date DESC";
$registrationsResult = mysqli_query($conn, $sql);

require_once 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>Registrations List</h1>
        <p>This table displays the student registrations currently stored in the project database.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ($registrationsResult && mysqli_num_rows($registrationsResult) > 0): ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th scope="col">Student Name</th>
                            <th scope="col">Student ID</th>
                            <th scope="col">Email</th>
                            <th scope="col">Event</th>
                            <th scope="col">Registration Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($registration = mysqli_fetch_assoc($registrationsResult)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($registration['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($registration['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($registration['email']); ?></td>
                                <td><?php echo htmlspecialchars($registration['event_title']); ?></td>
                                <td><?php echo date('d M Y, g:i A', strtotime($registration['registration_date'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h2>No registrations yet</h2>
                <p>Completed student registrations will appear on this page.</p>
                <a class="button" href="register.php">Open Registration Form</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
