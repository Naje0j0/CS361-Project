<?php
require_once 'includes/db.php';
$pageTitle = 'Events';
$eventsResult = mysqli_query($conn, "SELECT * FROM events ORDER BY event_date ASC, event_time ASC");
require_once 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>Campus Events</h1>
        <p>Browse all scheduled activities and open the event page to read the full details before registering.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ($eventsResult && mysqli_num_rows($eventsResult) > 0): ?>
            <div class="event-grid">
                <?php while ($event = mysqli_fetch_assoc($eventsResult)): ?>
                    <article class="event-card">
                        <img src="<?php echo htmlspecialchars($event['image']); ?>" alt="<?php echo htmlspecialchars($event['title']); ?>">
                        <div class="event-card-content">
                            <span class="badge"><?php echo htmlspecialchars($event['category']); ?></span>
                            <h3><?php echo htmlspecialchars($event['title']); ?></h3>
                            <p><?php echo htmlspecialchars(mb_strimwidth($event['description'], 0, 130, '...')); ?></p>
                            <ul class="meta-list">
                                <li><strong>Date:</strong> <?php echo date('d M Y', strtotime($event['event_date'])); ?></li>
                                <li><strong>Time:</strong> <?php echo date('g:i A', strtotime($event['event_time'])); ?></li>
                                <li><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></li>
                            </ul>
                            <a class="button button-outline" href="event.php?id=<?php echo (int) $event['id']; ?>">View Details</a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h2>No events found</h2>
                <p>The events list is currently empty.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
