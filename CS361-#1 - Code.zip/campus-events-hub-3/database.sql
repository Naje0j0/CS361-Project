CREATE DATABASE IF NOT EXISTS campus_events_hub_3
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE campus_events_hub_3;

DROP TABLE IF EXISTS registrations;
DROP TABLE IF EXISTS events;

CREATE TABLE events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    description TEXT NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    location VARCHAR(180) NOT NULL,
    capacity INT UNSIGNED NOT NULL DEFAULT 50,
    image VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE registrations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(120) NOT NULL,
    student_id VARCHAR(20) NOT NULL,
    email VARCHAR(160) NOT NULL,
    event_id INT UNSIGNED NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_registration_event
        FOREIGN KEY (event_id) REFERENCES events(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT unique_student_event UNIQUE (student_id, event_id)
) ENGINE=InnoDB;

INSERT INTO events (title, category, description, event_date, event_time, location, capacity, image) VALUES
('Cybersecurity Awareness Workshop', 'Workshop', 'A practical session about safe passwords, phishing messages, account protection, and responsible use of university systems. Students will work through short real-life examples.', '2026-08-02', '16:00:00', 'SEU Riyadh Campus - Training Hall 2', 60, 'images/event-workshop.jpg'),
('Saudi Vision 2030 Seminar', 'Seminar', 'A student-focused discussion about Vision 2030, digital transformation, future skills, and how university graduates can contribute to national development.', '2026-08-04', '13:30:00', 'SEU Riyadh Campus - Main Auditorium', 120, 'images/event-seminar.jpg'),
('Web Development Competition', 'Competition', 'Teams will build a small responsive website during a timed challenge. Projects will be evaluated for usability, design, code organization, and presentation.', '2026-08-06', '10:00:00', 'SEU Dammam Campus - Computer Lab 4', 48, 'images/event-competition.jpg'),
('Artificial Intelligence Career Talk', 'Career Talk', 'Professionals from the Saudi technology sector will discuss entry-level AI careers, required skills, internships, and responsible use of intelligent systems.', '2026-08-09', '18:00:00', 'Online through SEU Virtual Classroom', 200, 'images/event-ai.jpg'),
('Riyadh Cultural Trip', 'Trip', 'A supervised student visit to cultural and historical locations in Riyadh. The trip supports social connection and awareness of local heritage.', '2026-08-12', '08:00:00', 'Departure from SEU Riyadh Campus', 40, 'images/event-trip.jpg'),
('Entrepreneurship Skills Workshop', 'Workshop', 'Students will practise turning an idea into a simple business model, identifying customers, estimating basic costs, and presenting a short pitch.', '2026-08-15', '15:00:00', 'SEU Jeddah Campus - Innovation Room', 55, 'images/event-entrepreneurship.jpg');
