<?php
require_once 'includes/db.php';

$pageTitle = 'Register';
$errors = [];
$successMessage = '';
$studentName = '';
$studentId = '';
$email = '';
$selectedEventId = '';
$registeredEventTitle = '';

if (isset($_GET['event_id']) && ctype_digit($_GET['event_id'])) {
    $selectedEventId = (int) $_GET['event_id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentName = trim($_POST['student_name'] ?? '');
    $studentId = strtoupper(trim($_POST['student_id'] ?? ''));
    $email = trim($_POST['email'] ?? '');
    $selectedEventId = trim($_POST['event_id'] ?? '');

    if ($studentName === '' || $studentId === '' || $email === '' || $selectedEventId === '') {
        $errors[] = 'All registration fields are required.';
    }

    if ($studentName !== '' && mb_strlen($studentName) < 3) {
        $errors[] = 'The student name must contain at least three characters.';
    }

    if ($studentId !== '' && !preg_match('/^S?\d{6,12}$/', $studentId)) {
        $errors[] = 'Enter a valid student ID, such as S230011676.';
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    $eventExists = false;
    if ($selectedEventId !== '' && ctype_digit((string) $selectedEventId) && (int) $selectedEventId > 0) {
        $eventId = (int) $selectedEventId;
        $eventStmt = mysqli_prepare($conn, 'SELECT title FROM events WHERE id = ?');
        mysqli_stmt_bind_param($eventStmt, 'i', $eventId);
        mysqli_stmt_execute($eventStmt);
        $eventResult = mysqli_stmt_get_result($eventStmt);
        $eventRow = mysqli_fetch_assoc($eventResult);
        mysqli_stmt_close($eventStmt);

        if ($eventRow) {
            $eventExists = true;
            $registeredEventTitle = $eventRow['title'];
        }
    }

    if ($selectedEventId !== '' && !$eventExists) {
        $errors[] = 'Please select a valid event.';
    }

    if (!$errors) {
        $duplicateStmt = mysqli_prepare($conn, 'SELECT id FROM registrations WHERE student_id = ? AND event_id = ?');
        mysqli_stmt_bind_param($duplicateStmt, 'si', $studentId, $eventId);
        mysqli_stmt_execute($duplicateStmt);
        $duplicateResult = mysqli_stmt_get_result($duplicateStmt);
        $duplicateFound = mysqli_num_rows($duplicateResult) > 0;
        mysqli_stmt_close($duplicateStmt);

        if ($duplicateFound) {
            $errors[] = 'This student ID is already registered for the selected event.';
        } else {
            $insertStmt = mysqli_prepare($conn, 'INSERT INTO registrations (student_name, student_id, email, event_id) VALUES (?, ?, ?, ?)');
            mysqli_stmt_bind_param($insertStmt, 'sssi', $studentName, $studentId, $email, $eventId);

            if (mysqli_stmt_execute($insertStmt)) {
                $successMessage = 'Registration completed successfully for ' . $registeredEventTitle . '.';
                $studentName = '';
                $studentId = '';
                $email = '';
                $selectedEventId = '';
            } else {
                $errors[] = 'The registration could not be saved. Please try again.';
            }

            mysqli_stmt_close($insertStmt);
        }
    }
}

$eventsResult = mysqli_query($conn, 'SELECT id, title, event_date FROM events ORDER BY event_date ASC');
require_once 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>Student Registration</h1>
        <p>Complete the form below to reserve a place in one campus activity.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="form-card">
            <?php if ($errors): ?>
                <div class="message message-error" role="alert">
                    <strong>Please correct the following:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($successMessage): ?>
                <div class="message message-success" role="status">
                    <?php echo htmlspecialchars($successMessage); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="post" novalidate>
                <div class="form-row">
                    <div>
                        <label for="student_name">Student name</label>
                        <input type="text" id="student_name" name="student_name" value="<?php echo htmlspecialchars($studentName); ?>" required maxlength="120" autocomplete="name">
                    </div>
                    <div>
                        <label for="student_id">Student ID</label>
                        <input type="text" id="student_id" name="student_id" value="<?php echo htmlspecialchars($studentId); ?>" required maxlength="20" placeholder="S230011676">
                    </div>
                </div>

                <div class="form-row">
                    <div>
                        <label for="email">University email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required maxlength="160" autocomplete="email">
                    </div>
                    <div>
                        <label for="event_id">Selected event</label>
                        <select id="event_id" name="event_id" required>
                            <option value="">Choose an event</option>
                            <?php while ($eventOption = mysqli_fetch_assoc($eventsResult)): ?>
                                <option value="<?php echo (int) $eventOption['id']; ?>" <?php echo (string) $selectedEventId === (string) $eventOption['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($eventOption['title']); ?> - <?php echo date('d M Y', strtotime($eventOption['event_date'])); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <button class="button" type="submit">Submit Registration</button>
            </form>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
