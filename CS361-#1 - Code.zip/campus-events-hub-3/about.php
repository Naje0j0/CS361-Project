<?php
$pageTitle = 'About and Contact';
$contactErrors = [];
$contactSuccess = '';
$name = '';
$email = '';
$subject = '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '' || $email === '' || $subject === '' || $message === '') {
        $contactErrors[] = 'All contact form fields are required.';
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $contactErrors[] = 'Enter a valid email address.';
    }

    if ($message !== '' && mb_strlen($message) < 15) {
        $contactErrors[] = 'The message must contain at least 15 characters.';
    }

    if (!$contactErrors) {
        $contactSuccess = 'Thank you for contacting us. Your message has been received.';
        $name = '';
        $email = '';
        $subject = '';
        $message = '';
    }
}

require_once 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>About the Club</h1>
        <p>Learn about the purpose of the website, meet the project team, and send a simple enquiry.</p>
    </div>
</section>

<section class="section">
    <div class="container about-grid">
        <div>
            <article class="info-card">
                <p class="eyebrow">Our Purpose</p>
                <h2>SEU Student Activities Club</h2>
                <p>The club supports useful activities outside regular classes. Campus Events Hub gives students one clear place to view event information and submit registrations online.</p>
                <p>The project focuses on simple event publishing, reliable form validation, and clear access to stored registration information.</p>
            </article>

            <div class="team-grid team-grid-spaced">
                <article class="team-card">
                    <h3>Naje Alanazi</h3>
                    <p>S230011676</p>
                </article>
                <article class="team-card">
                    <h3>Tariq Alanazi</h3>
                    <p>S220018465</p>
                </article>
                <article class="team-card">
                    <h3>Azd Ahmed Rawah</h3>
                    <p>S230011850</p>
                </article>
                <article class="team-card">
                    <h3>Nawaf Aldossari</h3>
                    <p>S230006942</p>
                </article>
            </div>
        </div>

        <div class="form-card">
            <h2>Contact Us</h2>
            <p>Use this form to send a question or suggestion. Email delivery is not required for this academic project.</p>

            <?php if ($contactErrors): ?>
                <div class="message message-error" role="alert">
                    <ul>
                        <?php foreach ($contactErrors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($contactSuccess): ?>
                <div class="message message-success" role="status">
                    <?php echo htmlspecialchars($contactSuccess); ?>
                </div>
            <?php endif; ?>

            <form action="about.php" method="post" novalidate>
                <div>
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required maxlength="120">
                </div>
                <div>
                    <label for="contact_email">Email</label>
                    <input type="email" id="contact_email" name="email" value="<?php echo htmlspecialchars($email); ?>" required maxlength="160">
                </div>
                <div>
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" value="<?php echo htmlspecialchars($subject); ?>" required maxlength="160">
                </div>
                <div>
                    <label for="message">Message</label>
                    <textarea id="message" name="message" required maxlength="1000"><?php echo htmlspecialchars($message); ?></textarea>
                </div>
                <button class="button" type="submit">Send Message</button>
            </form>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
