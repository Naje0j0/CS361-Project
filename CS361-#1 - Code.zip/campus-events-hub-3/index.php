<?php
require_once 'includes/db.php';

$pageTitle = 'Home';

$sql = "SELECT * FROM events
        WHERE event_date >= CURDATE()
        ORDER BY event_date ASC, event_time ASC
        LIMIT 3";
$upcomingEvents = mysqli_query($conn, $sql);

require_once 'includes/header.php';
?>

<section class="hero">
    <div class="container hero-content">
        <p class="eyebrow">SEU Student Activities Club</p>
        <h1>Discover useful experiences beyond the classroom.</h1>
        <p>Explore upcoming workshops, seminars, competitions, career talks, and student trips across Saudi Electronic University campuses.</p>
        <a class="button button-accent" href="events.php">Explore Upcoming Events</a>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Coming Soon</p>
                <h2>Next three events</h2>
                <p>These are the nearest scheduled activities currently available for student registration.</p>
            </div>
            <a href="events.php">View all events</a>
        </div>

        <?php if ($upcomingEvents && mysqli_num_rows($upcomingEvents) > 0): ?>
            <div class="event-grid">
                <?php while ($event = mysqli_fetch_assoc($upcomingEvents)): ?>
                    <article class="event-card">
                        <img src="<?php echo htmlspecialchars($event['image']); ?>" alt="<?php echo htmlspecialchars($event['title']); ?>">
                        <div class="event-card-content">
                            <span class="badge"><?php echo htmlspecialchars($event['category']); ?></span>
                            <h3><?php echo htmlspecialchars($event['title']); ?></h3>
                            <ul class="meta-list">
                                <li><strong>Date:</strong> <?php echo date('d M Y', strtotime($event['event_date'])); ?></li>
                                <li><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></li>
                            </ul>
                            <a class="button button-outline" href="event.php?id=<?php echo (int) $event['id']; ?>">View Details</a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No upcoming events are available.</h3>
                <p>Please check again later for new student activities.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="section section-white">
    <div class="container">
        <div class="section-heading">
            <div>
                <p class="eyebrow">Student Experience</p>
                <h2>Why participate?</h2>
            </div>
        </div>
        <div class="benefit-grid">
            <article class="info-card">
                <h3>Build practical skills</h3>
                <p>Workshops and competitions provide chances to practise communication, technology, teamwork, and problem-solving.</p>
            </article>
            <article class="info-card">
                <h3>Meet other students</h3>
                <p>Campus activities create an easy way to connect with students from different programs and university branches.</p>
            </article>
            <article class="info-card">
                <h3>Explore career paths</h3>
                <p>Seminars and career talks introduce students to employers, emerging fields, and skills needed in the Saudi job market.</p>
            </article>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
