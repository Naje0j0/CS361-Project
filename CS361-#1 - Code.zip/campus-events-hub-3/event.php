<?php
require_once 'includes/db.php';

$pageTitle = 'Event Details';
$event = null;
$errorMessage = '';

if (!isset($_GET['id']) || !ctype_digit($_GET['id']) || (int) $_GET['id'] < 1) {
    $errorMessage = 'The event link is invalid. Please choose an event from the events page.';
} else {
    $eventId = (int) $_GET['id'];
    $stmt = mysqli_prepare($conn, 'SELECT * FROM events WHERE id = ?');
    mysqli_stmt_bind_param($stmt, 'i', $eventId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $event = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$event) {
        $errorMessage = 'The selected event could not be found.';
    } else {
        $pageTitle = $event['title'];
    }
}

require_once 'includes/header.php';
?>

<section class="page-banner">
    <div class="container">
        <h1>Event Details</h1>
        <p>Review the event information and register when you are ready.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ($errorMessage): ?>
            <div class="message message-error">
                <?php echo htmlspecialchars($errorMessage); ?>
            </div>
            <a class="button" href="events.php">Return to Events</a>
        <?php else: ?>
            <div class="detail-layout">
                <article>
                    <img class="detail-image" src="<?php echo htmlspecialchars($event['image']); ?>" alt="<?php echo htmlspecialchars($event['title']); ?>">
                    <span class="badge"><?php echo htmlspecialchars($event['category']); ?></span>
                    <h2><?php echo htmlspecialchars($event['title']); ?></h2>
                    <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                </article>

                <aside class="detail-card">
                    <h2>Event Information</h2>
                    <ul class="meta-list">
                        <li><strong>Date:</strong> <?php echo date('l, d F Y', strtotime($event['event_date'])); ?></li>
                        <li><strong>Time:</strong> <?php echo date('g:i A', strtotime($event['event_time'])); ?></li>
                        <li><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></li>
                        <li><strong>Capacity:</strong> <?php echo (int) $event['capacity']; ?> students</li>
                    </ul>
                    <a class="button button-accent" href="register.php?event_id=<?php echo (int) $event['id']; ?>">Register for This Event</a>
                </aside>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
